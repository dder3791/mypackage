package com.srpingboot.controller;

public class BytesHexStrTranslate {

	
	public static void main(String[] args) {
		int a=-77;
		byte b=(byte) a;
		
		byte[] int2ByteArray = int2ByteArray(a);
		
	}
	public static byte[] int2ByteArray(int i){
        byte[] result=new byte[4];
        result[0]=(byte)((i >> 24)& 0xFF);
        result[1]=(byte)((i >> 16)& 0xFF);
        result[2]=(byte)((i >> 8)& 0xFF);
        result[3]=(byte)(i & 0xFF);
        return result;
    }
}
