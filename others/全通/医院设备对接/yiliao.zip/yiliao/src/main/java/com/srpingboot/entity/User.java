package com.srpingboot.entity;

import java.util.Date;

public class User {
	String name;//系统用户名
	String password;//密码
	String power_vaule;//权限值
	Date power_term;//权限期限
	Date createDate;//创建时间
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPower_vaule() {
		return power_vaule;
	}
	public void setPower_vaule(String power_vaule) {
		this.power_vaule = power_vaule;
	}
	public Date getPower_term() {
		return power_term;
	}
	public void setPower_term(Date power_term) {
		this.power_term = power_term;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
}

