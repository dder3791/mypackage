package com.srpingboot.controller;



import java.util.Date;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.srpingboot.dao.UserMapper;
import com.srpingboot.entity.User;
import com.srpingboot.services.UserService;
import com.srpingboot.util.PageData;

@RestController
@RequestMapping("/User")
public class UserController extends BaseController{

    @Resource(name="userService")
    UserService  userService;
     
    
    @RequestMapping("/insertUser")
    @ResponseBody
    public String insertUser(String name,String password){
    	PageData pd = this.getPageData();
    	pd.put("name", name);
    	pd.put("password", password);
    	pd.put("createDate", new Date());
    	userService.insertUser(pd);
       return "插入成功";
    }
    
    @RequestMapping("/addUser")
    @ResponseBody
    public String addUser(){
    	User user = new User();
    	user.setName("llk");
    	user.setPassword("12345566");
    	user.setCreateDate(new Date());
    	userService.addUser(user);
    	return "插入成功";
    }
    
    
    @RequestMapping("/deleteUser")
    @ResponseBody
    public String deleteUser(){
    	User user = new User();
    	user.setName("llk");
    	userService.deleteUser(user);
    	return "删除成功";
    }
    
    
    @RequestMapping(value="/show")
    @ResponseBody
    public String show(){
    	System.out.println("");
    	return "你好";
    }
    
    
}
