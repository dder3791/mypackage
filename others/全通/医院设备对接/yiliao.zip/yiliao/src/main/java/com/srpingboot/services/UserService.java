package com.srpingboot.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srpingboot.dao.UserMapper;
import com.srpingboot.entity.User;
import com.srpingboot.util.PageData;

@Service("userService")
public class UserService {
	
	 @Autowired
	 UserMapper userMapper;
	 
	 public void addUser(User user){
		 userMapper.add(user);
	 }
	 
	 public void insertUser(PageData pd){
		 userMapper.insert(pd);
	 }
	 
	 public void deleteUser(User user){
		 
		 userMapper.delete(user);
	 }

}
