package com.srpingboot.dao;


import com.srpingboot.entity.User;
import com.srpingboot.util.PageData;


public interface UserMapper {

    public void insert(PageData pd);
    public void add(User user);
    public void delete(User user);
}
